package com.optimum.dao;

import com.optimum.pojo.User;

public class BankDAOImpl implements BankDAOInterface {

	static int balanceamount = 0;
	
	@Override
	public void checkBalance() {
	System.out.println("Current Balance : " + balanceamount);	

	}

	@Override
	public void deposit(User refUser) { // get the user input 
		
		balanceamount = refUser.getAmount() + balanceamount;
		System.out.println(refUser.getAmount() +" dollar deposited successfully!!");
		
	}

	@Override
	public void withdraw(User refUser) {
		
		if(refUser.getAmount() < balanceamount)
		{
		balanceamount = balanceamount - refUser.getAmount() ;
		System.out.println("Transaction Successful!!");
		}
		else
		{
			System.out.println("Sorry!! insufficient balance. ");
		}
		
	
		
	}

	@Override
	public void register(User refUser) {
		// TODO Auto-generated method stub
		System.out.println( refUser.getSecurityKey() + " is your security key in case if you forget your password ");
		System.out.println();
		System.out.println("Registration Successfully!!");
	}

	

	@Override
	public void userLogin(User refUser) {
		// TODO Auto-generated method stub
		System.out.println("Login Sucessful!!");
		
	}
	
	@Override
	public void forgetPassword(User refUser) {
		// TODO Auto-generated method stub
		System.out.println( refUser.getSecurityKey() + " is your security key in case if you forget your password ");
	
	}


}
